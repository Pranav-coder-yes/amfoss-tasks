from PySide6.QtWidgets import QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout
from PySide6.QtGui import QPixmap, QPalette, QBrush
from PySide6.QtCore import Qt
import requests


class SearchWindow(QWidget):
    def __init__(self):
        super().__init__()

        self.setFixedSize(850, 600)  # Adjusted size to accommodate more details
        self.setWindowTitle("Pokemon Search")

        # Create a label for background and set the background image
        self.background_label = QLabel(self)
        self.background_label.setGeometry(0, 0, self.width(), self.height())
        self.set_background_image("/home/pranav/amfoss-tasks/task-5/assets/landing.jpg")  # Replace with your actual image path

        # Create widgets above the background
        self.textbox = QLineEdit(self)
        self.textbox.setPlaceholderText("Enter Pokémon Name")
        self.textbox.setGeometry(50, 50, 280, 40)

        label1 = QLabel("Enter the name of the Pokémon:", self)
        label1.setGeometry(50, 5, 600, 70)

        # Creating buttons and positioning them
        self.enter_button = QPushButton("Search", self)
        self.enter_button.setGeometry(50, 100, 160, 43)
        self.enter_button.clicked.connect(self.fetch_pokemon)

        self.capture_button = QPushButton("Capture", self)
        self.capture_button.setGeometry(50, 150, 160, 43)
        self.capture_button.clicked.connect(self.capture_pokemon)

        self.display_button = QPushButton("Display Captured", self)
        self.display_button.setGeometry(50, 200, 160, 43)
        self.display_button.clicked.connect(self.display_captured_pokemon)

        # Create a label to display the Pokémon image above the background
        self.pokemon_image_label = QLabel(self)
        self.pokemon_image_label.setGeometry(400, 50, 200, 200)

        # Layout for Pokémon details
        self.details_area = QWidget(self)
        self.details_area.setGeometry(400, 250, 400, 250)
        self.details_layout = QVBoxLayout(self.details_area)
        self.details_area.setLayout(self.details_layout)

        self.name_label = QLabel("Name: ", self.details_area)
        self.details_layout.addWidget(self.name_label)

        self.abilities_label = QLabel("Abilities: ", self.details_area)
        self.details_layout.addWidget(self.abilities_label)

        self.types_label = QLabel("Types: ", self.details_area)
        self.details_layout.addWidget(self.types_label)

        self.stats_label = QLabel("Stats: ", self.details_area)
        self.details_layout.addWidget(self.stats_label)

        self.capture_label = QLabel("Captured: ", self.details_area)
        self.details_layout.addWidget(self.capture_label)

        # List to hold captured Pokémon
        self.captured_pokemon = []

    def set_background_image(self, image_path):
        """
        Method to set a background image for the main window.
        """
        pixmap = QPixmap(image_path).scaled(self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        self.background_label.setPixmap(pixmap)
        self.background_label.setScaledContents(True)

    def fetch_pokemon(self):
        pokemon_name = self.textbox.text().lower()
        if pokemon_name:
            pokemon_info = self.get_pokemon_info(pokemon_name)
            if pokemon_info:
                self.display_pokemon_info(pokemon_info)
            else:
                self.name_label.setText(f"Failed to fetch data for {pokemon_name}. Please try again.")
        else:
            self.name_label.setText("Please enter a Pokémon name.")

    def get_pokemon_info(self, name):
        url = f"https://pokeapi.co/api/v2/pokemon/{name}"
        response = requests.get(url)
        if response.status_code == 200:
            return response.json()
        else:
            return None

    def display_pokemon_info(self, pokemon_info):
        self.name_label.setText(f"Name: {pokemon_info['name'].capitalize()}")
        abilities = ', '.join([ability['ability']['name'] for ability in pokemon_info['abilities']])
        self.abilities_label.setText(f"Abilities: {abilities}")
        types = ', '.join([t['type']['name'] for t in pokemon_info['types']])
        self.types_label.setText(f"Types: {types}")
        stats = '\n'.join([f"{stat['stat']['name'].capitalize()}: {stat['base_stat']}" for stat in pokemon_info['stats']])
        self.stats_label.setText(f"Stats:\n{stats}")

        # Update the Pokémon image
        if 'sprites' in pokemon_info and pokemon_info['sprites']['front_default']:
            self.update_pokemon_image(pokemon_info['sprites']['front_default'])
        else:
            self.pokemon_image_label.setText("No image available.")

        # Capture the Pokémon when the user clicks the capture button
        self.current_pokemon_info = pokemon_info

    def update_pokemon_image(self, image_url):
        """
        Method to update the Pokémon image from URL.
        """
        response = requests.get(image_url)
        if response.status_code == 200:
            pixmap = QPixmap()
            pixmap.loadFromData(response.content)
            self.pokemon_image_label.setPixmap(pixmap)
            self.pokemon_image_label.setScaledContents(True)
        else:
            self.pokemon_image_label.setText("Failed to load image.")

    def capture_pokemon(self):
        """
        Captures the current Pokémon and adds it to the captured list.
        """
        if hasattr(self, 'current_pokemon_info'):
            self.captured_pokemon.append(self.current_pokemon_info)
            self.capture_label.setText(f"Captured: {self.current_pokemon_info['name'].capitalize()}")
        else:
            self.capture_label.setText("No Pokémon to capture. Please search first.")

    def display_captured_pokemon(self):
        """
        Displays only the list of captured Pokémon names.
        """
        if self.captured_pokemon:
            captured_names = "\n".join([pokemon['name'].capitalize() for pokemon in self.captured_pokemon])
            self.name_label.setText(f"Captured Pokémon:\n{captured_names}")
            # Clear other labels
            self.abilities_label.setText("")
            self.types_label.setText("")
            self.stats_label.setText("")
            self.capture_label.setText("")
            self.pokemon_image_label.clear()  # Remove the Pokémon image
        else:
            self.name_label.setText("No Pokémon captured yet.")
            # Clear other labels
            self.abilities_label.setText("")
            self.types_label.setText("")
            self.stats_label.setText("")
            self.capture_label.setText("")
            self.pokemon_image_label.clear()  # Remove the Pokémon image


if __name__ == "__main__":
    import sys
    from PySide6.QtWidgets import QApplication

    app = QApplication(sys.argv)
    window = SearchWindow()
    window.show()
    sys.exit(app.exec())
